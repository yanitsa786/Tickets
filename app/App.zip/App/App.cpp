#include <iostream>
#include "App.h"
using namespace std;

int main()
{
	App app;
	app.run();
}